----------------------------------------------------------------------------------
-- Company: University of Kansas - Instrumentation Lab
-- Engineer: Felipe Tala
-- 
-- Create Date: 07/31/2025 01:16:53 PM
-- Design Name: Drone ADC
-- Module Name: tb_adc - testbench
-- Project Name: Drone 8-channel ADC
-- Target Devices: Artix 7
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;


---------------------- ENTITY -------------------------

entity adc is
    Port(
            clk, reset, cs, rd, busy : in  STD_LOGIC;
            db                       : in  STD_LOGIC_VECTOR (15 downto 0);
            busy_sync                : out STD_LOGIC;
            cs_bar, rd_bar           : out STD_LOGIC;
            adder                    : out STD_LOGIC_VECTOR (3 downto 0);
            fifo_count_sync          : out STD_LOGIC_VECTOR(4 downto 0);
            convst                   : out STD_LOGIC_VECTOR (15 downto 0)
    );
end adc;


------------------- ARCHITECTURE ----------------------

architecture Behavioral of adc is

    type adc_state is (idle, wait_start, read_adc, done);
    
------------------------ SIGNALS -------------------------
    
    ------ STATES, COUNTER, WAIT TIME ------
    
    signal current_state, next_state: adc_state;
    signal wait_counter: integer := 0;
    constant wait_time: integer := 1700; -- 1.7 us       
    
    ---- CONVST OUTPUT ----
    
    signal convst_sig : STD_LOGIC_VECTOR(15 downto 0);

    ----- FIFO ------
    
    type fifo_array is array(0 to 15) of STD_LOGIC_VECTOR(15 downto 0);    
    signal fifo: fifo_array:= (others =>(others =>'0'));
    signal fifo_count: unsigned(4 downto 0) := (others => '0');
    signal count_sig: STD_LOGIC_VECTOR(4 downto 0);
    
    signal wr_ptr: unsigned(3 downto 0) := (others => '0'); -- FIFO Write pointer
    signal rd_ptr: unsigned(3 downto 0) := (others => '0'); -- FIFO Read pointer
    
    signal busy_sig: STD_LOGIC; -- busy signal, used for synchronizing busy to clock
    signal read_enable: STD_LOGIC := '0'; -- FIFO read enabling
    

--------------------- STATE REGISTER ---------------------

begin
    convst <= convst_sig; -- output convst
    adder <= STD_LOGIC_VECTOR(wr_ptr); -- Channel FIFO address
    
    process(clk, reset)
    begin
        if reset = '1' then
            current_state <= idle;
            wr_ptr <= (others => '0');
            rd_ptr <= (others => '0');
            fifo_count <= (others => '0');
            read_enable <= '0';

        elsif rising_edge(clk) then
            current_state <= next_state;
            
            if wait_counter < wait_time then
                wait_counter <= wait_counter + 1;
            else
                wait_counter <= 0;
            end if;
        end if;
    end process;
        
    
---------------------- FIFO WRITING ------------    
    
    process(clk, reset)
    begin
        if reset = '1' then
            wr_ptr <= (others => '0');
            fifo_count <= (others => '0');
        elsif rising_edge(clk) then
            if current_state = read_adc then
                if fifo_count < 16 then
                    fifo(to_integer(wr_ptr)) <= db; -- store ADC value
                    wr_ptr <= (wr_ptr + 1) mod 16;
                    fifo_count <= fifo_count + 1; -- ISSUE IS IN PASSING UNSIGNED TO STD_LOGIC_VECTOR
                end if;
            end if;
        end if;
    end process;
                    
----------------------- FIFO READING --------------------------

process(clk, reset)
    begin
        if reset = '1' then
            rd_ptr <= (others => '0');
            convst_sig <= (others => '0');
            read_enable <= '0';
        elsif rising_edge(clk) then
            if current_state = done then
                read_enable <= '1';
            end if;
            
            if read_enable = '1' then
                if fifo_count > 0 then
                    convst_sig <= fifo(to_integer(rd_ptr));
                    rd_ptr <= (rd_ptr + 1) mod 16;
                    fifo_count <= fifo_count - 1;
                    fifo_count_sync <= STD_LOGIC_VECTOR(fifo_count);
               else
                    read_enable <= '0';
               end if;
            end if;
        end if;
     end process;


------ FIFO SYNC (just for visualization, delete after) -------

--      process(clk)
--      begin
--        if rising_edge(clk) then
--            count_sig <= ;
--        end if;
--      end process;
      
--      fifo_count_sync <= count_sig;
    
----------------- BUSY-CLK SYNCHRONIZING SIGNAL ---------------
    
    process(clk)
    begin
        if rising_edge(clk) then
            busy_sig <= busy;
        end if;
    end process;
    
    busy_sync <= busy_sig;
        
-------------------- NEXT STATE LOGIC ----------------------
    
    
    process(current_state, busy_sig, wait_counter, cs, rd)
    begin
        next_state <= current_state;
        cs_bar <= '1';
        rd_bar <= '1';
        
        case current_state is
            when idle =>
                if cs = '0' and rd = '0' then
                    cs_bar <= not(cs);
                    rd_bar <= not(rd);
                    next_state <= wait_start;
                end if;
                        
            when wait_start =>
                if wait_counter = wait_time then
                    next_state <= read_adc;
                end if;
            when read_adc =>
                if wait_counter = wait_time then
                    if to_integer(wr_ptr) = 15 then
                        next_state <= done;
                    else
                        next_state <= wait_start;
                    end if;
                end if;
                
            when done =>
                if cs = '1' and rd = '1' then
                    next_state <= idle;
                else
                    next_state <= done;
                end if;
               
            when others =>
                next_state <= idle;
        end case;    
    end process;
    
end Behavioral;
