----------------------------------------------------------------------------------
-- Company: University of Kansas - Instrumentation Lab
-- Engineer: Felipe Tala
-- 
-- Create Date: 07/31/2025 01:16:53 PM
-- Design Name: Drone ADC
-- Module Name: tb_adc - testbench
-- Project Name: Drone 8-channel ADC Testbench
-- Target Devices: Artix 7
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_adc is
end tb_adc;

architecture testbench of tb_adc is

    component adc
        Port(
            clk, reset, cs, rd, busy : in  STD_LOGIC;
            db                       : in  STD_LOGIC_VECTOR (15 downto 0);
            busy_sync                : out STD_LOGIC;
            cs_bar, rd_bar           : out STD_LOGIC;
            adder                    : out STD_LOGIC_VECTOR (3 downto 0);
            fifo_count_sync          : out STD_LOGIC_VECTOR(4 downto 0);
            convst                   : out STD_LOGIC_VECTOR (15 downto 0)
    );
    end component;

    signal clk_tb         : STD_LOGIC;
    signal reset_tb       : STD_LOGIC;
    signal cs_tb          : STD_LOGIC;
    signal rd_tb          : STD_LOGIC;
    signal cs_bar_tb      : STD_LOGIC;
    signal rd_bar_tb      : STD_LOGIC;
    signal db_tb          : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');
    signal busy_tb        : STD_LOGIC;
    signal busy_sync_tb   : STD_LOGIC;
    signal fifo_count_sync_tb     : STD_LOGIC_VECTOR(4 downto 0);
    signal convst_tb      : STD_LOGIC_VECTOR(15 downto 0);

    constant clk_period : time := 10 ns; -- RECHECK

begin

------------------------- DUT -----------------------

    DUT: adc
        port map (
            clk => clk_tb,
            reset => reset_tb,
            cs => cs_tb,
            rd => rd_tb,
            db => db_tb,
            rd_bar => rd_bar_tb,
            cs_bar => cs_bar_tb,
            busy => busy_tb,
            busy_sync => busy_sync_tb,
            fifo_count_sync => fifo_count_sync_tb,
            convst => convst_tb
        );

---------------------- CLOCK GENERATION ---------------------------

    clk_process : process
    begin
        while true loop
            clk_tb <= '0';
            wait for clk_period/2;
            clk_tb <= '1';
            wait for clk_period/2;
        end loop;
    end process;

-------------------- STIMULUS PROCESS ---------------------------

    stim_proc: process
    begin
   
        reset_tb <= '1';
        wait for clk_period*10;
        reset_tb <= '0';
        busy_tb <= '1';
        
        wait for clk_period*5;
        busy_tb <= '0';
        cs_tb <= '1';
        rd_tb <= '1';
        
        wait for clk_period*2;        
        db_tb <= x"ABCD";                   -- 1st ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');
        
        wait for clk_period*2;        
        rd_tb <= '1';
        db_tb <= x"FFFF";                   -- 2nd ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');

        wait for clk_period*2;        
        rd_tb <= '1';
        db_tb <= x"1234";                   -- 3rd ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');
        
        wait for clk_period*2;        
        rd_tb <= '1';
        db_tb <= x"A1B2";                   -- 4th ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');

        wait for clk_period*2;        
        rd_tb <= '1';
        db_tb <= x"5E28";                   -- 5th ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');

        wait for clk_period*2;        
        rd_tb <= '1';
        db_tb <= x"789A";                   -- 6th ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');
        
        wait for clk_period*2;        
        rd_tb <= '1';
        db_tb <= x"C941";                   -- 7th ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');
        
        wait for clk_period*2;        
        rd_tb <= '1';
        db_tb <= x"DACB";                   -- 8th ADC sample (16 bit HEX)
        
        wait for clk_period*2;        
        rd_tb <= '0';
        db_tb <= (others => '0');
        busy_tb <= '1';
                                      -- used to stop loop
        wait for clk_period*2;
        reset_tb <= '1';
        cs_tb <= '0';
        rd_tb <= '0';

    end process;

end testbench;
