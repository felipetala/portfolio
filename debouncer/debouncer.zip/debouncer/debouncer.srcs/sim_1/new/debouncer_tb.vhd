----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 08/25/2025 04:37:06 PM
-- Design Name: 
-- Module Name: debouncer_tb - sim
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all;
use std.env.finish;
library UNISIM;
use UNISIM.VComponents.all;

entity debouncer_tb is
end debouncer_tb;

architecture sim of debouncer_tb is

    constant clk_hz: real := 100.0e6;
    constant clk_period: time := 1 sec / clk_hz;
    
    constant switch_count: positive := 8;
    constant timeout_cycles : positive := 100;
    
    signal clk: std_logic := '1';
    signal rst: std_logic := '1';
    signal switch: std_logic;
    signal switch_debounced: std_logic;

begin

    clk <= not clk after clk_period / 2;
    
    DUT : entity work.debouncer(rtl)
        generic map (
        timeout_cycles => timeout_cycles
        )
        port map(
            clk => clk,
            rst => rst,
            switch => switch,
            switch_debounced => switch_debounced
            );
            
            SEQUENCER_PROC : process
                procedure flip_and_bounce is
                begin
                    report "Flipping switch from " &
                        std_logic'image(switch) &
                        std_logic'image(not switch);
                    for i in 0 to 6 loop
                        switch <= not switch;
                        wait for clk_period;
                    end loop;
                end procedure;
        begin
            switch <= '0';
            
            wait for 10 * clk_period;
            rst <= '0';
            
            wait for 10 * clk_period;
            flip_and_bounce;
            
            wait for 200 * clk_period;
            flip_and_bounce;
            
            wait for 200 * clk_period;

            finish;

        end process;
end sim;
