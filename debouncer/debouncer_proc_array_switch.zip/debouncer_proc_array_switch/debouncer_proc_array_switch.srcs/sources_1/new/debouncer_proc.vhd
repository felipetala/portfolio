----------------------------------------------------------------------------------
-- Company: The University of Kansas
-- Engineer: Felipe Tala
-- 
-- Create Date: 08/26/2025 01:49:56 PM
-- Design Name: 
-- Module Name: debouncer_proc - rtl
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity debouncer_proc is
    generic(
        switch_count: positive := 8;
        timeout_cycles: positive := 100
        );
    port(
        clk: in std_logic;
        rst: in std_logic;
        switches: in std_logic_vector(switch_count - 1 downto 0);
        switches_debounced: out std_logic_vector(switch_count - 1 downto 0)
    );
end debouncer_proc;

architecture rtl of debouncer_proc is
begin

    MY_GEN: for i in 0 to switch_count - 1 generate
        
        signal debounced: std_logic;
        signal counter: integer range 0 to timeout_cycles - 1;
        
    begin
        
        switches_debounced(i) <= debounced;
        
        DEBOUNCE_PROC: process(clk)
        begin
            if rising_edge(clk) then
                if rst = '1' then
                    counter <= 0;
                    debounced <= switches(i);
                else
                    if counter < timeout_cycles - 1 then
                        counter <= counter + 1;
                    elsif switches(i) /= debounced then
                        counter <= 0;
                        debounced <= switches(i);
                    end if;
                end if;
            end if;
        end process;
    end generate;
end rtl;
