----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 08/26/2025 02:03:19 PM
-- Design Name: 
-- Module Name: debouncer_proc_tb - rtl
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use std.env.finish;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity debouncer_proc_tb is
end debouncer_proc_tb;

architecture rtl of debouncer_proc_tb is

    constant clk_hz: real := 100.0e6;
    constant clk_period: time := 1 sec / clk_hz;
    
    signal switch_count: positive := 8;
    signal timeout_cycles: positive := 100;
    
    signal clk: std_logic := '1';
    signal rst: std_logic := '1';
    signal switches: std_logic_vector(switch_count - 1 downto 0);
    signal switches_debounced: std_logic_vector(switch_count - 1 downto 0);

begin

    clk <= not clk after clk_period / 2;
    
    DUT: entity work.debouncer_proc(rtl) --Device Under Test
        generic map(
            switch_count => switch_count,
            timeout_cycles => timeout_cycles
        )
        port map(
            clk => clk,
            rst => rst,
            switches => switches,
            switches_debounced => switches_debounced
        );
        
        SEQUENCER_PROC: process
        
            procedure flip_and_bounce (switch_num : integer) is
            begin
                report "Flipping switch" & integer'image(switch_num) &
                    " from " & std_logic'image(switches(switch_num)) &
                    " to " & std_logic'image(not switches(switch_num));
                for i in 0 to 6 loop
                    switches(switch_num) <= not switches(switch_num);
                    wait for clk_period;
                end loop;
            end procedure;
            
        begin
            switches <= (others => '0');
            
            wait for 10 * clk_period;
            rst <= '0';
            
            wait for 10 * clk_period;
            flip_and_bounce(3);
            
            wait for 200 * clk_period;
            flip_and_bounce(7);
            
            wait for 200 * clk_period;
            
            finish;
            
        end process;
end rtl;
