----------------------------------------------------------------------------------
-- Company: The University of Kansas
-- Engineer: Felipe Tala
-- 
-- Create Date: 08/25/2025 03:48:49 PM
-- Design Name: 
-- Module Name: debouncer_switch_array - rtl
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use std.env.finish;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity debouncer_switch_array is
    generic(
        switch_count : positive;
        timeout_cycles: positive
        );
    Port(
        clk: in std_logic;
        rst: in std_logic;
        switches: in std_logic_vector(switch_count - 1 downto 0);
        switches_debounced: out std_logic_vector(switch_count - 1 downto 0)
    );
end debouncer_switch_array;


architecture rtl of debouncer_switch_array is
begin 

    MY_GEN : for i in 0 to switch_count - 1 generate  
        
        DEBOUNCER : entity work.deb(rtl)
        generic map(
            timeout_cycles => timeout_cycles
        )
        port map(
            clk => clk,
            rst => rst,
            switch => switches(i),
            switch_debounced => switches_debounced(i)
         );
    end generate;
    
end architecture;
