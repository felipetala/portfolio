----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 08/25/2025 03:48:49 PM
-- Design Name: 
-- Module Name: deb - rtl
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use std.env.finish;

library UNISIM;
use UNISIM.VCOMPONENTS.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity deb is
    generic(
        timeout_cycles: positive
        );
    Port(
        clk: in std_logic;
        rst: in std_logic;
        switch: in std_logic;
        switch_debounced: out std_logic
    );
end deb;


architecture rtl of deb is

    signal debounced: std_logic;
    signal counter: integer range 0 to timeout_cycles - 1;

begin

    switch_debounced <= debounced;
    
    DEBOUNCE_PROC: process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                counter <= 0;
                debounced <= switch;
                
            else
                
                if counter < timeout_cycles - 1 then
                    counter <= counter + 1;
                elsif switch /= debounced then
                    counter <= 0;
                    debounced <= switch;
                end if;
             end if;
         end if;
     end process;
end architecture;
