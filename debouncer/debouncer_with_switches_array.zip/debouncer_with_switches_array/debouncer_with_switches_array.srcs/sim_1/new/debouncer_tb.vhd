----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 08/25/2025 04:37:06 PM
-- Design Name: 
-- Module Name: debouncer_switch_array_tb - sim
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all;
use std.env.finish;

library UNISIM;
use UNISIM.VComponents.all;

entity debouncer_switch_array_tb is
end debouncer_switch_array_tb;

architecture sim of debouncer_switch_array_tb is

    constant clk_hz: real := 100.0e6;
    constant clk_period: time := 1 sec / clk_hz;
    
    constant switch_count: positive := 8;
    constant timeout_cycles : positive := 100;
    
    signal clk: std_logic := '1';
    signal rst: std_logic := '1';
    signal switches: std_logic_vector(switch_count - 1 downto 0);
    signal switches_debounced: std_logic_vector(switch_count - 1 downto 0);

begin

    clk <= not clk after clk_period / 2;
    
    DUT : entity work.debouncer_switch_array(rtl)
        generic map (
            switch_count => switch_count,
            timeout_cycles => timeout_cycles
        )
        port map(
            clk => clk,
            rst => rst,
            switches => switches,
            switches_debounced => switches_debounced
        );
            
            SEQUENCER_PROC : process
                procedure flip_and_bounce (switch_num: integer) is
                begin
                    report "Flipping switch" & integer'image(switch_num) &
                    " from " & std_logic'image(switches(switch_num)) &
                    " to " & std_logic'image(not switches(switch_num));
                        
                    for i in 0 to 6 loop
                        switches(switch_num) <= not switches(switch_num);
                        wait for clk_period;
                    end loop;
                end procedure;
        begin
            
            switches <= (others => '0'); -- used instead of '0' for arrays
            
            wait for 10 * clk_period;
            rst <= '0';
            
            wait for 10 * clk_period;
            flip_and_bounce(5);
            
            wait for 200 * clk_period;
            flip_and_bounce(5);
            
            wait for 200 * clk_period;
            
            finish;

        end process;
end sim;
